const targetTime = new Date(Date.UTC(2022, 3, 1, 2, 59, 0));

export default targetTime;